def neverend():
    print("neverend")
    neverend()
neverend()