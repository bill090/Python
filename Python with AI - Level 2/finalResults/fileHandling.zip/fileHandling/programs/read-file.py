f = open("demofile.txt", "r")
print(f.read())
f.close()