import shutil
source = "/home/bill/Downloads/right_click_save.png"
destination = "/home/bill/Python/Python with AI - Level 2/fileHandling/files/back-file.bak"
shutil.copy(source, destination)