f = open("../datainparent.txt", 'a')
f.write("Welcome tp Python with AI Level 2! \n")
f.write("Now the file has more content!")
f.close()

f = open("data.txt", "a")
f.write('Welcome to Python with AI Level 2! \n')
f.write("now the file has more content!")
f.close()