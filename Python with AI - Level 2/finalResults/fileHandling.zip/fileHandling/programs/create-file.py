f = open("/home/bill/Python/Python with AI - Level 2/fileHandling/files/demofile.txt", "a")
f.write("Welcome to Python with AI Level 2!  \n")
f.write("Now the file has more content!")
f.close()